#include "node.h"
#include <iostream>

using namespace std;

template<typename T>
class forward_list {
private:
    node<T> *FRONT;
    int n;
public:
    forward_list() {
        FRONT = NULL;
        n = 0;        
    }

    forward_list(const forward_list &src) {
        FRONT = NULL;
        operator=(src);
    }

    void operator=(const forward_list &src) {
        if (FRONT != NULL)
            clear();

        node<T> *temp_src, *nn, *temp;
        temp_src = src.FRONT;
        while(temp_src != NULL) {
            nn = new node<T>;
            nn->data = temp_src->data;
            nn->next = NULL;
            
            if (FRONT == NULL)
                FRONT = nn;
            else            
                temp->next = nn;

            temp = nn;
            temp_src = temp_src->next;
        }
        n = src.n;
    }

    ~forward_list() {
        clear();
    }

    void push_front(const T &val) {
        node<T> *temp;
        temp = new node<T>;
        if (temp == NULL) {
            throw("List Overflow!");
        }
        temp->data = val;
        if (FRONT == NULL) //if list is empty
            temp->next = NULL;
        else                //if list is not empty
            temp->next = FRONT;
        FRONT = temp;
        n++;
    }

    T front() const {
        if (FRONT == NULL)
            throw("List Underflow!");
        return FRONT->data;
    }

    void pop_front()  {
        if (FRONT == NULL) { //if (empty())
            throw("List Underflow!");
        }
        node<T> *temp;
        temp = FRONT;
        FRONT = FRONT->next;
        delete temp;
        n--;
    }

    bool empty() const {
        // return FRONT == NULL;
        if (FRONT == NULL)
            return true;
        else
            return false;
    }

    bool full() const {
        node<T> *temp;
        temp = new node<T>;
        if (temp == NULL) {
            return true;
        } else {
            delete temp;
            return false;
        }
    }

    void clear() {
        while(!empty()) {
            pop_front();
        }
        // n = 0;
    }

    bool find(T &val) const {
        node<T> *temp;
        temp = FRONT;
        while (temp != NULL) {
            if (temp->data == val) {
                val = temp->data; //copy satellite data. Only useful in case of structures or objects.
                return true;
            } else {
                temp = temp->next;
            }
        }
        return false;
    }

    int size() const {
        return n;
    }
};